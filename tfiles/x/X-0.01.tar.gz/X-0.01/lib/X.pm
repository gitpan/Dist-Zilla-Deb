package X;
BEGIN {
  $X::VERSION = '0.01';
}

use strict;
use warnings;

# ABSTRACT: XXX

1;

